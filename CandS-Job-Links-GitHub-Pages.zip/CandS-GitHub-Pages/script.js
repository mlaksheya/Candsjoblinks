/* ==========================================================
   CandS Job Links — Site behavior
   Reads everything from SITE_CONFIG (config.js) and renders it.
   You should not need to edit this file — see config.js instead.
   ========================================================== */

(function () {
  const cfg = window.SITE_CONFIG || {};
  const c = cfg.company || {};
  const contact = cfg.contact || {};
  const social = cfg.social || {};

  const ICONS = {
    it: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="4" width="18" height="12" rx="1.5"/><path d="M8 20h8M12 16v4"/></svg>',
    nonit: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 21V9l8-5 8 5v12"/><path d="M9 21v-6h6v6"/></svg>',
    pharma: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="7" y="3" width="10" height="18" rx="5"/><path d="M7 12h10"/></svg>',
    phone: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3 19.5 19.5 0 0 1-6-6 19.8 19.8 0 0 1-3-8.7A2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 2 .7 3a2 2 0 0 1-.5 2.1L8 10.1a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.5c1 .3 2 .5 3 .7a2 2 0 0 1 1.6 2Z"/></svg>',
    mail: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="m2 7 10 6 10-6"/></svg>',
    pin: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>',
    clock: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 3"/></svg>',
    check: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 6 9 17l-5-5"/></svg>',
    coin: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="9"/><path d="M9 12h6M12 9v6"/></svg>',
    whatsapp: '<svg width="28" height="28" viewBox="0 0 24 24" fill="currentColor"><path d="M12.04 2C6.58 2 2.13 6.45 2.13 11.91c0 1.85.5 3.58 1.36 5.07L2 22l5.2-1.44a9.87 9.87 0 0 0 4.84 1.24h.01c5.46 0 9.9-4.45 9.9-9.9C21.95 6.45 17.5 2 12.04 2Zm0 17.9c-1.5 0-2.98-.4-4.26-1.16l-.3-.18-3.09.86.85-3.01-.2-.31a8.02 8.02 0 0 1-1.24-4.19c0-4.44 3.62-8.06 8.07-8.06 4.44 0 8.05 3.62 8.05 8.06s-3.6 7.99-8.08 7.99Zm4.4-6.01c-.24-.12-1.43-.7-1.65-.79-.22-.08-.38-.12-.55.12-.16.24-.63.79-.77.95-.14.16-.28.18-.52.06-.24-.12-1.02-.38-1.94-1.2-.72-.64-1.2-1.43-1.34-1.67-.14-.24-.02-.37.1-.49.11-.11.24-.28.36-.42.12-.14.16-.24.24-.4.08-.16.04-.3-.02-.42-.06-.12-.55-1.33-.76-1.82-.2-.48-.4-.42-.55-.42h-.47c-.16 0-.42.06-.64.3-.22.24-.84.82-.84 2s.86 2.32.98 2.48c.12.16 1.7 2.6 4.12 3.64.58.25 1.03.4 1.38.51.58.18 1.11.16 1.53.1.47-.07 1.43-.58 1.63-1.15.2-.56.2-1.04.14-1.15-.06-.1-.22-.16-.46-.28Z"/></svg>',
    linkedin: '<svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M4.98 3.5a2.5 2.5 0 1 1 0 5 2.5 2.5 0 0 1 0-5ZM3 9h4v12H3V9Zm7 0h3.8v1.7h.05c.53-1 1.83-2.05 3.77-2.05 4.03 0 4.78 2.65 4.78 6.1V21h-4v-5.3c0-1.27-.02-2.9-1.77-2.9-1.77 0-2.04 1.38-2.04 2.8V21h-4V9Z"/></svg>',
    facebook: '<svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M13.5 21v-8h2.7l.4-3.2h-3.1V7.7c0-.9.25-1.5 1.55-1.5H16.7V3.3C16.4 3.25 15.4 3.16 14.25 3.16c-2.4 0-4.05 1.47-4.05 4.16v2.32H7.5v3.2h2.7v8h3.3Z"/></svg>',
    instagram: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.2" cy="6.8" r="1"/></svg>',
    twitter: '<svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M22 5.9c-.7.3-1.5.6-2.3.7a4 4 0 0 0 1.75-2.2c-.78.46-1.65.8-2.57.99a4.05 4.05 0 0 0-6.9 3.7A11.5 11.5 0 0 1 3.4 4.6a4.05 4.05 0 0 0 1.25 5.4c-.66-.02-1.28-.2-1.83-.5v.05a4.05 4.05 0 0 0 3.25 4 4.1 4.1 0 0 1-1.82.07 4.05 4.05 0 0 0 3.78 2.82A8.13 8.13 0 0 1 2 18.4a11.5 11.5 0 0 0 6.22 1.82c7.46 0 11.54-6.18 11.54-11.54l-.01-.53c.79-.57 1.48-1.28 2.02-2.09Z"/></svg>',
  };

  function el(html) {
    const t = document.createElement('template');
    t.innerHTML = html.trim();
    return t.content.firstElementChild;
  }

  function setText(id, value, fallbackHide) {
    const node = document.getElementById(id);
    if (!node) return;
    if (!value && fallbackHide) {
      node.remove();
      return;
    }
    node.textContent = value || '';
  }

  // ---------- Brand / logo ----------
  function renderBrand() {
    document.title = `${c.name || 'CandS Job Links'} — ${c.tagline || 'Placement Services'}`;
    document.querySelectorAll('.js-brand-name').forEach(n => n.textContent = c.name || 'CandS Job Links');
    document.querySelectorAll('.js-brand-tagline').forEach(n => n.textContent = c.tagline || '');

    document.querySelectorAll('.js-logo-slot').forEach(slot => {
      slot.innerHTML = '';
      if (c.logoUrl) {
        const img = document.createElement('img');
        img.src = c.logoUrl;
        img.alt = `${c.name || 'Company'} logo`;
        slot.appendChild(img);
      } else {
        const mark = document.createElement('span');
        mark.className = 'brand-mark';
        mark.textContent = c.shortName || (c.name ? c.name.slice(0, 2).toUpperCase() : 'CS');
        slot.appendChild(mark);
      }
    });
  }

  // ---------- Hero ----------
  function renderHero() {
    const heroTagline = document.getElementById('hero-tagline');
    if (heroTagline) heroTagline.textContent = c.tagline || 'Placement services across IT, Non-IT & Pharma';
    const about = document.getElementById('about-text');
    if (about) about.textContent = c.aboutText || '';

    const trust = document.getElementById('trust-strip');
    if (trust) {
      const items = [];
      if (c.gstNumber) items.push(`<span><strong>GST:</strong> ${c.gstNumber}</span>`);
      if (c.cinOrRegNumber) items.push(`<span><strong>Reg. No:</strong> ${c.cinOrRegNumber}</span>`);
      if (c.yearFounded) items.push(`<span><strong>Since:</strong> ${c.yearFounded}</span>`);
      if (contact.phone) items.push(`<span><strong>Call:</strong> ${contact.phone}</span>`);
      if (items.length) {
        trust.innerHTML = items.join('');
      } else {
        trust.remove();
      }
    }
  }

  // ---------- Sectors ----------
  function renderSectors() {
    const wrap = document.getElementById('sector-grid');
    if (!wrap) return;
    const sectors = cfg.sectors || [];
    const colorMap = { it: 'var(--tag-it)', nonit: 'var(--tag-nonit)', pharma: 'var(--tag-pharma)' };
    wrap.innerHTML = sectors.map(s => `
      <div class="sector-card" style="--sector-color:${colorMap[s.icon] || 'var(--brass)'}">
        <div class="sector-icon">${ICONS[s.icon] || ICONS.it}</div>
        <span class="sector-tag">${s.tag || ''}</span>
        <h3>${s.name || ''}</h3>
        <p>${s.description || ''}</p>
      </div>
    `).join('');
  }

  // ---------- Process ----------
  function renderProcess() {
    const wrap = document.getElementById('process-list');
    if (!wrap) return;
    const steps = cfg.process || [];
    wrap.innerHTML = steps.map((s, i) => `
      <div class="process-item">
        <div class="process-num">${String(i + 1).padStart(2, '0')}</div>
        <div>
          <h3>${s.title || ''}</h3>
          <p>${s.description || ''}</p>
        </div>
      </div>
    `).join('');
  }

  // ---------- Vendor empanelment ----------
  function renderVendors() {
    const section = document.getElementById('vendor-section');
    const ve = cfg.vendorEmpanelment || {};
    const list = ve.list || [];
    if (!section) return;

    const introEl = document.getElementById('vendor-intro');
    if (introEl) introEl.textContent = ve.introText || '';

    const tableWrap = document.getElementById('vendor-table-wrap');
    if (!list.length) {
      tableWrap.innerHTML = `<div class="vendor-empty">Vendor empanelment details will appear here once added in config.js.</div>`;
      return;
    }
    tableWrap.innerHTML = `
      <table class="vendor-table">
        <thead><tr><th>Company</th><th>Sector</th><th>Empanelment ID</th></tr></thead>
        <tbody>
          ${list.map(v => `<tr><td>${v.company || ''}</td><td>${v.sector || ''}</td><td>${v.empanelmentId || '—'}</td></tr>`).join('')}
        </tbody>
      </table>`;
  }

  // ---------- Fees & pay modes ----------
  function renderFees() {
    const feeNote = document.getElementById('fee-note');
    if (feeNote) feeNote.textContent = (cfg.fees || {}).note || '';

    const payList = document.getElementById('pay-modes-list');
    if (payList) {
      const modes = cfg.payModes || [];
      payList.innerHTML = modes.map(m => `<li>${ICONS.coin}${m.name}</li>`).join('');
    }

    const bank = cfg.bankDetails || {};
    const bankBox = document.getElementById('bank-box');
    const rows = [
      ['Account name', bank.accountName],
      ['Account number', bank.accountNumber],
      ['Bank', bank.bankName],
      ['IFSC', bank.ifsc],
      ['UPI ID', bank.upiId],
    ].filter(r => r[1]);
    if (bankBox) {
      if (!rows.length) { bankBox.remove(); }
      else {
        bankBox.innerHTML = rows.map(r => `<div><span>${r[0]}</span><span>${r[1]}</span></div>`).join('');
      }
    }
  }

  // ---------- Contact ----------
  function renderContact() {
    const addr = contact.address || {};
    const addrParts = [addr.line1, addr.line2, addr.city, addr.state, addr.pincode, addr.country].filter(Boolean);
    const list = document.getElementById('contact-list');
    if (list) {
      const rows = [];
      if (addrParts.length) rows.push(`<li>${ICONS.pin}<span>${addrParts.join(', ')}</span></li>`);
      if (contact.phone) rows.push(`<li>${ICONS.phone}<a href="tel:${contact.phone.replace(/\s+/g,'')}">${contact.phone}</a></li>`);
      if (contact.email) rows.push(`<li>${ICONS.mail}<a href="mailto:${contact.email}">${contact.email}</a></li>`);
      if (contact.officeHours) rows.push(`<li>${ICONS.clock}<span>${contact.officeHours}</span></li>`);
      list.innerHTML = rows.join('') || `<li><span>Add your contact details in config.js</span></li>`;
    }

    const mapWrap = document.getElementById('map-wrap');
    if (mapWrap) {
      if (contact.mapEmbedUrl) {
        mapWrap.innerHTML = `<div class="map-embed"><iframe src="${contact.mapEmbedUrl}" loading="lazy" referrerpolicy="no-referrer-when-downgrade" title="Office location"></iframe></div>`;
      } else {
        mapWrap.innerHTML = `<div class="map-placeholder">Add a Google Maps embed link in config.js to show your office location here.</div>`;
      }
    }
  }

  // ---------- Footer ----------
  function renderFooter() {
    const year = document.getElementById('footer-year');
    if (year) year.textContent = new Date().getFullYear();
    const nameEls = document.querySelectorAll('.js-footer-name');
    nameEls.forEach(n => n.textContent = c.name || 'CandS Job Links');

    const legal = document.getElementById('footer-legal');
    if (legal) {
      const bits = [];
      if (c.gstNumber) bits.push(`GST: ${c.gstNumber}`);
      if (c.cinOrRegNumber) bits.push(`Reg. No: ${c.cinOrRegNumber}`);
      legal.innerHTML = bits.map(b => `<span>${b}</span>`).join('');
    }

    const socialWrap = document.getElementById('footer-social');
    if (socialWrap) {
      const links = [
        ['linkedin', social.linkedin],
        ['facebook', social.facebook],
        ['instagram', social.instagram],
        ['twitter', social.twitter],
      ].filter(([, url]) => url);
      socialWrap.innerHTML = links.map(([key, url]) => `<a href="${url}" target="_blank" rel="noopener">${ICONS[key]}</a>`).join('');
    }
  }

  // ---------- Floating WhatsApp ----------
  function renderWhatsapp() {
    const btn = document.getElementById('float-whatsapp');
    if (!btn) return;
    if (contact.whatsapp) {
      btn.href = `https://wa.me/${contact.whatsapp.replace(/\D/g, '')}`;
      btn.style.display = 'flex';
    } else {
      btn.style.display = 'none';
    }
  }

  // ---------- Nav / phone shortcuts ----------
  function renderNavExtras() {
    document.querySelectorAll('.js-nav-phone').forEach(n => {
      if (contact.phone) {
        n.href = `tel:${contact.phone.replace(/\s+/g, '')}`;
        n.innerHTML = `${ICONS.phone}<span>${contact.phone}</span>`;
      } else {
        n.remove();
      }
    });
  }

  // ---------- Mobile nav toggle ----------
  function initNavToggle() {
    const toggle = document.querySelector('.nav-toggle');
    const nav = document.querySelector('.main-nav');
    if (!toggle || !nav) return;
    toggle.addEventListener('click', () => {
      nav.classList.toggle('open');
      toggle.setAttribute('aria-expanded', nav.classList.contains('open'));
    });
    nav.querySelectorAll('a').forEach(a => a.addEventListener('click', () => nav.classList.remove('open')));
  }

  document.addEventListener('DOMContentLoaded', () => {
    renderBrand();
    renderHero();
    renderSectors();
    renderProcess();
    renderVendors();
    renderFees();
    renderContact();
    renderFooter();
    renderWhatsapp();
    renderNavExtras();
    initNavToggle();
  });
})();
