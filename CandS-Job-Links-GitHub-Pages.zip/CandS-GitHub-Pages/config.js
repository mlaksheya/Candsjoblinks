/* ============================================================
   CandS Job Links — SITE SETTINGS
   ============================================================
   This is the ONLY file you need to edit to update your website.
   Everything here shows up automatically on the live site —
   you never need to touch index.html, style.css, or script.js.

   HOW TO EDIT:
   1. Open this file in any text editor (Notepad, TextEdit, VS Code).
   2. Change the text between the quotes " " — don't remove the quotes.
   3. Save the file and refresh the website to see your changes.
   4. Leave a field as "" (empty quotes) to hide that item on the site.
   ============================================================ */

const SITE_CONFIG = {

  // -------------------- COMPANY IDENTITY --------------------
  company: {
    name: "CandS Job Links",
    shortName: "C&S",                 // used in the logo mark
    tagline: "Placement services across IT, Non-IT & Pharma",
    // Path or web address to your logo image. Leave "" to use a text logo instead.
    // Recommended: a square or wide PNG/SVG with a transparent background.
    logoUrl: "",
    aboutText: "CandS Job Links helps job seekers find the right opportunity and helps companies find the right people — across IT, Non-IT, and Pharma sectors. We work on a minimal, transparent fee so both candidates and employers get a fast, reliable placement process.",
    gstNumber: "",                    // e.g. "27ABCDE1234F1Z5"
    cinOrRegNumber: "",                // Company registration / CIN number
    yearFounded: "",                   // e.g. "2018" — leave "" to hide "Since ____"
  },

  // -------------------- CONTACT DETAILS --------------------
  contact: {
    phone: "",                         // e.g. "+91 98765 43210"
    whatsapp: "",                      // digits only with country code, e.g. "919876543210"
    email: "",                         // e.g. "contact@candsjoblinks.com"
    address: {
      line1: "",
      line2: "",
      city: "",
      state: "",
      pincode: "",
      country: "India",
    },
    // Paste a Google Maps "Embed a map" src URL here to show a live map.
    // Maps > Share > Embed a map > copy the src="..." link only. Leave "" to hide the map.
    mapEmbedUrl: "",
    officeHours: "Mon – Sat, 10:00 AM – 6:30 PM",
  },

  // -------------------- SOCIAL LINKS (optional) --------------------
  // Leave any of these as "" to hide that icon.
  social: {
    linkedin: "",
    facebook: "",
    instagram: "",
    twitter: "",
  },

  // -------------------- SECTORS YOU PLACE CANDIDATES IN --------------------
  // Add, remove, or edit sectors freely — the page updates automatically.
  sectors: [
    {
      name: "Information Technology",
      tag: "IT",
      description: "Software, QA, support, data, and infrastructure roles for candidates ready to join fast-moving tech teams.",
      icon: "it",
    },
    {
      name: "Non-IT",
      tag: "Non-IT",
      description: "Operations, sales, admin, customer service, and business support roles across a wide range of industries.",
      icon: "nonit",
    },
    {
      name: "Pharma",
      tag: "Pharma",
      description: "Field sales, production, quality, and regulatory roles with pharmaceutical and healthcare companies.",
      icon: "pharma",
    },
  ],

  // -------------------- HOW IT WORKS --------------------
  // This is shown as a numbered process — edit the steps to match how you actually work.
  process: [
    {
      title: "Share your profile",
      description: "Candidates submit their resume and preferred sector; companies share their open roles and requirements.",
    },
    {
      title: "We match and shortlist",
      description: "Our team reviews profiles against open roles across our IT, Non-IT, and Pharma network.",
    },
    {
      title: "Interview is arranged",
      description: "We coordinate interviews directly with the hiring company and keep you updated at each stage.",
    },
    {
      title: "Offer and minimal fee",
      description: "Once an offer is confirmed, our minimal service fee applies — details are always shared upfront.",
    },
  ],

  // -------------------- VENDOR EMPANELMENT --------------------
  // List the companies / panels you are empanelled with as a hiring vendor.
  // Leave the array empty ( [] ) to hide this section entirely.
  vendorEmpanelment: {
    introText: "CandS Job Links is an empanelled recruitment vendor with the organisations below, authorised to source and refer candidates for open positions.",
    list: [
      // Example — replace with your real empanelments:
      // { company: "Example Corp Pvt Ltd", sector: "IT", empanelmentId: "VEN-1042" },
    ],
  },

  // -------------------- FEES & PAYMENT --------------------
  fees: {
    note: "We charge a minimal, transparent placement fee only after an offer is confirmed. Exact fee details are shared with candidates and companies before any commitment.",
  },
  payModes: [
    { name: "UPI" },
    { name: "Bank Transfer / NEFT / IMPS" },
    { name: "Cheque / Demand Draft" },
    { name: "Cash (office visit only)" },
  ],
  // Optional — shown under Pay Modes if you want to publish bank details for transfers.
  bankDetails: {
    accountName: "",
    accountNumber: "",
    bankName: "",
    ifsc: "",
    upiId: "",
  },
};
