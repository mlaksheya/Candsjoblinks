# How to edit your website

Your site is 4 files. You will only ever need to open **config.js**.

```
index.html      → page structure (don't edit)
style.css       → colors, fonts, layout (don't edit)
script.js       → makes the page dynamic (don't edit)
config.js       → YOUR CONTENT — edit this one
```

## Editing your details

1. Open `config.js` in any plain text editor (Notepad on Windows, TextEdit on
   Mac — set TextEdit to "Plain Text" mode — or a free code editor like VS Code).
2. Find the section you want to change (they're labelled in capital letters
   with `// ----` dividers, e.g. `CONTACT DETAILS`, `SECTORS`, `VENDOR EMPANELMENT`).
3. Type your text between the quote marks `" "`. Don't delete the quote marks
   or the commas at the end of lines.
4. Save the file, then open `index.html` in your browser to preview.
5. Leave a field as `""` (empty) to hide it — for example, if you don't have
   a CIN number yet, the "Reg. No" tag simply won't show on the site.

## Common things you'll want to add first

- **Phone / WhatsApp / email** → `contact` section
- **Address** → `contact.address`
- **GST number** → `company.gstNumber`
- **Company registration / CIN** → `company.cinOrRegNumber`
- **Logo** → `company.logoUrl` — upload your logo file next to `index.html`
  and set this to its filename, e.g. `"logo.png"`
- **Vendor empanelment list** → `vendorEmpanelment.list` — copy the example
  row and fill in each company you're empanelled with
- **Bank details for transfers** → `bankDetails`
- **Google Map** → in Google Maps, open your location → Share → Embed a map →
  copy only the link inside `src="..."` and paste it into `contact.mapEmbedUrl`

## Publishing the site

This is a static site — no server or database needed. You can put these four
files (plus your logo, if any) on any of the following and it will work:

- **Netlify** or **Vercel**: drag the folder onto their "deploy" page (free, easiest)
- **GitHub Pages**: push the folder to a repository and enable Pages
- Any shared web hosting you already own: upload via FTP into the public folder

No build step, no installation — just upload the files as they are.

## If something looks broken

The most common cause is a missing comma or quote mark in `config.js` after
an edit. Compare the line you changed to the lines around it — every text
value should be wrapped in quotes `" "` and each line (except the last in a
group) should end with a comma `,`.
